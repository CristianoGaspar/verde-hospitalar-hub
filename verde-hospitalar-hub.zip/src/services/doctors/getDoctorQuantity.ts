import { http } from "@/api/http";

export const getDoctorQuantity = async () => {
  const response = await http.get("/doctors/quantity");
  return response.data.total;
};
